import { reactRouter } from "@react-router/dev/vite";
import path from "path";
import { defineConfig } from "vite";
import tsconfigPaths from "vite-tsconfig-paths";

// Related: https://github.com/remix-run/remix/issues/2835#issuecomment-1144102176
// Replace the HOST env var with SHOPIFY_APP_URL so that it doesn't break the Vite server.
// The CLI will eventually stop passing in HOST,
// so we can remove this workaround after the next major release.
if (
  process.env.HOST &&
  (!process.env.SHOPIFY_APP_URL ||
    process.env.SHOPIFY_APP_URL === process.env.HOST)
) {
  process.env.SHOPIFY_APP_URL = process.env.HOST;
  delete process.env.HOST;
}

const host = new URL(process.env.SHOPIFY_APP_URL || "http://localhost")
  .hostname;
let hmrConfig;

if (host === "localhost") {
  hmrConfig = {
    protocol: "ws",
    host: "localhost",
    port: 64999,
    clientPort: 64999,
  };
} else {
  hmrConfig = {
    protocol: "wss",
    host: host,
    port: parseInt(process.env.FRONTEND_PORT) || 8002,
    clientPort: 443,
  };
}

export default defineConfig(({ isSsrBuild }) => ({
  server: {
    allowedHosts: [host],
    cors: {
      preflightContinue: true,
    },
    port: Number(process.env.PORT || 3000),
    hmr: hmrConfig,
    fs: {
      // See https://vitejs.dev/config/server-options.html#server-fs-allow for more information
      allow: ["app", "node_modules"],
    },
  },
  plugins: [reactRouter(), tsconfigPaths()],
  build: {
    assetsInlineLimit: 0,
    rollupOptions: isSsrBuild
      ? {
        input: "./server/app.js",
      }
      : undefined,
  },
  optimizeDeps: {
    include: ["@shopify/app-bridge-react"],
  },
  resolve: {
    alias: {
      'shopify-server': path.resolve(__dirname, './app/shopify.server.js'),
      'db-server': path.resolve(__dirname, './app/db.server.js'),
      '@app': path.resolve(__dirname, './app'),
      'app': path.resolve(__dirname, './app'),
      'db-server.js': path.resolve(__dirname, './app/db.server.js'),
      '@components': path.resolve(__dirname, './app/components'),
      '@atoms': path.resolve(__dirname, './app/atoms'),
      '@controller': path.resolve(__dirname, './app/controller'),
      '@graphql': path.resolve(__dirname, './app/graphql'),
      '@routes': path.resolve(__dirname, './app/routes'),
      '@utils': path.resolve(__dirname, './app/utils'),
      '@shared-utils': path.resolve(__dirname, './app/layout/points-rules/shared-utils'),
    }
  }
}));
